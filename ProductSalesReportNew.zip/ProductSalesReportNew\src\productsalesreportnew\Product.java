package productsalesreportnew;


import productsalesreportnew.IProduct;


public class Product implements IProduct {

    private final int[][] sales;

    public Product(int[][] sales) {
        this.sales = sales;
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;

        for (int[] productSales : sales) {
            for (int monthlySales : productSales) {
                total += monthlySales;
            }
        }

        return total;
    }

    @Override
    public double GetAverageProductsSold() {
        if (sales.length == 0) {
            return 0;
        }

        return (double) GetTotalProductsSold()
                / sales.length;
    }

    @Override
    public String GetMostPopularProduct() {
        String[] products = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        int highestSales = -1;
        String popularProduct = "";

        for (int i = 0; i < sales.length; i++) {
            int total = 0;

            for (int monthlySales : sales[i]) {
                total += monthlySales;
            }

            if (total > highestSales) {
                highestSales = total;
                popularProduct = products[i];
            }
        }

        return popularProduct;
    }
}
