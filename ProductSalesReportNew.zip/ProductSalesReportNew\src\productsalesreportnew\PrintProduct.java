package productsalesreportnew;


import java.util.Scanner;

public class PrintProduct {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String[] products = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        int[][] sales = new int[3][3];

        for (int i = 0; i < products.length; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(
                    "Enter number of sales for month "
                    + (j + 1) + " for "
                    + products[i] + " mattress: "
                );

                sales[i][j] = input.nextInt();
            }

            System.out.println();
        }

        Product product = new Product(sales);

        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println(
            "********************************"
        );

        System.out.println(
            "TOTAL PRODUCT SALES: "
            + product.GetTotalProductsSold()
        );

        System.out.printf(
            "AVERAGE PRODUCT SALES: %.0f%n",
            product.GetAverageProductsSold()
        );

        System.out.println(
            "MOST POPULAR PRODUCT: "
            + product.GetMostPopularProduct()
        );
    }
}
